#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 void list()
{
	/*char exitOption;*/
    system("cls");
    printf("\n\n\n");
    printf("=========================================== BUS RESERVATION SYSTEM ============================================\n\n\n");
    printf("\t\t\t\t\t[1]  =>  %s\n","ch[0]");
    printf("\n");
    printf("\t\t\t\t\t[2]  =>  %s\n","ch[1]");
    printf("\n");
	printf("\t\t\t\t\t[3]  =>  %s\n","ch[2]");
    printf("\n");
	printf("\t\t\t\t\t[4]  =>  %s\n","ch[3]");
    printf("\n");
	printf("\t\t\t\t\t[5]  =>  %s\n","ch[4]");
	  /*printf("Do you wanna Exit: Y/N");
	  scanf("%d",exitOption);
	  if(exitOption == 1 )
	  {
	  	goto dashboard;
	  }
	  else
	  {
		  exit(0);
	  }*/
 }
 int main()
{

  char Name;
  int TransportationFee;
  char Destination;
  int SeatNumber;
  int DepartureTime;
  int Amount;
char secondName;
  int PlaceChoice;
  int BusNumber;
  char Book;
  char Cancel;
  char Nairobi;
  char Check;
  static int p = 0;
  char Answer;
  char Mombasa;
  char Kisumu;
  char Eldoret;
  char Place;
  int Choice;

  
 dashboard:
     printf("\n\n\n\n\n");
    printf("\n\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");
    printf("\n\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t        =                  WELCOME                  =");
    printf("\n\t\t\t        =                     TO                    =");
    printf("\n\t\t\t        =                 FADHILI                   =");
    printf("\n\t\t\t        =                TRANSPORT COMPANY          =");
    printf("\n\t\t\t        =                                           =");
    printf("\n\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");
    printf("FOR CUSTOMER CARE SERVICES : CALL OR SMS\n");
    printf("                             0791719298\n");
   time_t t;   // not a primitive datatype
    
    
    printf("=========================================\n");
    printf("                                        \n");

  printf("==========================================BUS RESERVATION SYSTEM===========================================\n\n\n");
  printf("\t\t\t\t\t(1) View Bus list\n\n");
  printf("\t\t\t\t\t(2) Book a Ticket\n\n");
  printf("\t\t\t\t\t(3) Check your Booking\n\n");
  printf("\t\t\t\t\t(4) Cancel a Booking\n\n");
  printf("\t\t\t\t\t\(5) Exit\n\n");
  printf("===============================================================================================================\n\n");

  printf("\t\t\tEnter Your Choice:: ");
  scanf("%d",&Choice);

switch (Choice)
{
    case 1:
        list();
        break;

    

case 2:
{
  printf("Enter your Name:");
 scanf("%s%s", &Name, &secondName);
     printf("\t\tWelcome:%s%s\n", &Name);
           printf("%s", &secondName);

  printf( "Locations:\n");
  printf("1) Nairobi----Mombasa\n");
  printf("\tTransportationFee==1500\n");

  printf("2) Mombasa----Nairobi\n");
  printf("\tTransportationFee==1000\n");

  printf("3) Kisumu----Mombasa\n");
  printf("\tTransportationFee==3500\n");

  printf("4) Mombasa----Kisumu\n");
  printf("\tTransportationFee==3200\n");

  printf("5) Nairobi----Eldoret\n");
  printf("\tTransportationFee==1200\n");

  printf("6) Eldoret----Nairobi\n");
  printf("\tTransportationFee==1000\n");

    printf("Enter Choice:");
    scanf("%d", &PlaceChoice);
    printf("\tHow would you like to pay?\n");
    printf("1) M-Pesa\n");
    printf("2) Cancel Booking\n");
    printf("Answer:");
    scanf("\n%d", &Answer);

switch (Answer)
  {
      case 1:
      	 printf("Make payment to proceed:\n");
      	  printf("Enter the Amount:");
      	  scanf("\n%d", &Amount);
break;
      case 2:
       printf("Thank you");
  }
    printf("Enter DepartureTime:");
    scanf("\n%d", &DepartureTime);
    printf("Enter BusNumber:-");
    scanf("\n%d", &BusNumber);
    
    
  printf("\t\t\t\tSEAT ARRAGEMENT:\n");
  printf("\t\t\t\t================\n");
  printf("\t\t\t\t\t[Driver]\n");
  printf("\t\t\t\t [ 1 2     3 4   ]\n");
  printf("\t\t\t\t [ 5 6     7 8   ]\n");
  printf("\t\t\t\t [ 9 10    11 12 ]\n");
  printf("\t\t\t\t [13 14    15 16 ]\n");
  printf("\t\t\t\t [17 18    19 20 ]\n");
  printf("\t\t\t\t [21 22    23 24 ]\n");
  printf("\t\t\t\t [25 26    27 28 ]\n");
  printf("\t\t\t\t [29 30    31 32 ]\n");
  printf("\t\t\t\t [33 34    35 36 ]\n");
  printf("\t\t\t\t [37 38    39 40 ]\n");
  printf("\t\t\t\t [41 42 43 44 45 ]\n");

 printf("Choose a seat no:");
    scanf("%d", &SeatNumber);	
    /*if(seat>45)
  {
    printf("There are only 45 seats available);	
    printf("&BusNumber");
  } else
  {
     print("The seat no. ia already reserved.\n");	
  }*/
/*int n;
for(n=0;n<=p;n++)
   if(strcmp(bus[n].seat[seat/4][seat%4-1], "Empty")==0)
   
    break;
   while (n<=p)
  {	
   else if(strcmp(bus[n].seat[seat/4][(seat%4)-1], "Empty")==0) 
  {
     printf("Enter passenger's name");
     printf("bus[n].seat[seat/4][(seat%4)-1];");
    break;
  }
    if(n>p)
	{
	  printf("Enter correct BusNmber\n");	
	} 	
*/

switch(PlaceChoice)
switch(Place)
{
case 1:
      printf("\t\t\tCongratulations you have successfully booked a ticket\n");
      printf("\t\t\tBOOKING DETAILS\n");
      printf("\t\t\t================\n");
      printf("\t\t\tName:%s%s\n", &Name, &Name);
      printf("\t\t\tDestination: Mombasa\n");
      printf("\t\t\tSeatNumber:%d\n", SeatNumber);
      printf("\t\t\tDepartureTime:%d\n", DepartureTime);
      printf("\t\t\tTransportFee: 1500 \n");
      printf("\t\t\tCAUTION: TAKE CARE OF YOUR OWN GOODS!\n");
      printf("\t\t\tWe value you\n" );
    break ;

case 2:
     printf("\t\t\tCongratulations you have successfully booked a ticket\n");
     printf("\t\t\tBOOKING DETAILS\n");
     printf("\t\t\t================\n");
     printf("\t\t\tName:%s%s\n", &Name, &Name);
     printf("\t\t\tDestination: Nairobi\n");
     printf("\t\t\tSeatNumber:%d\n", SeatNumber);
     printf("\t\t\tDepartureTime:%d\n", DepartureTime);
     printf("\t\t\tTransportFee : 1000 %d\n", TransportationFee);
     printf("\t\t\tCAUTION: TAKE CARE OF YOUR OWN GOODS!\n");
     printf("\t\t\tWe value you\n" );
    break ;
case 3:

     printf("\t\t\tCongratulations you have successfully booked a ticket\n");
     printf("\t\t\tBOOKING DETAILS\n");
     printf("\t\t\t================\n");
     printf("\t\t\tName:%s%s\n", &Name, &Name);
     printf("\t\t\tDestination: Mombasa");
     printf("\t\t\tSeatNumber:%d\n", SeatNumber);
     printf("\t\t\tDepartureTime:%d\n", DepartureTime);
     printf("\t\t\tTransportFee : 3500 %d\n", TransportationFee);
     printf("\t\t\tCAUTION: TAKE CARE OF YOUR OWN GOODS!\n");
     printf("\t\t\tWe value you\n" );
     break ;
case 4:
    printf("\t\t\tCongratulations you have successfully booked a ticket\n");
    printf("\t\t\tBOOKING DETAILS\n");
    printf("\t\t\t================\n");
    printf("\t\t\tName:%s%s\n", &Name, &Name);
    printf("\t\t\tDestination: Kisumu");
    printf("\t\t\tSeatNumber:%d\n", SeatNumber);
    printf("\t\t\tDepartureTime:%d\n", DepartureTime);
    printf("\t\t\tTransportFee : 3200 %d\n", TransportationFee);
    printf("\t\t\tCAUTION: TAKE CARE OF YOUR OWN GOODS!\n");
    printf("\t\t\tWe value you\n" );
    break;
case 5:
    printf("\t\t\tCongratulations you have successfully booked a ticket\n");
    printf("\t\t\tBOOKING DETAILS\n");
    printf("\t\t\t================\n");
    printf("\t\t\tName:%s%s\n", &Name, &Name);
    printf("\t\t\tDestination: Eldoret");
    printf("\t\t\tSeatNumber:%d\n", SeatNumber);
    printf("\t\t\tDepartureTime:%d\n", DepartureTime);
    printf("\t\t\tTransportFee : 1200 %d\n", TransportationFee);
    printf("\t\t\tCAUTION: TAKE CARE OF YOUR OWN GOODS!\n");
    printf("\t\t\tWe value you\n" );
    break;
case 6:
    printf("\t\t\tCongratulations you have successfully booked a ticket\n");
    printf("\t\t\tBOOKING DETAILS\n");
    printf("\t\t\t================\n");
    printf("\t\t\tName:%s%s\n", &Name, &Name);
    printf("\t\t\tDestination: Nairobi");
    printf("\t\t\tSeatNumber:%d\n", SeatNumber);
    printf("\t\t\tDepartureTime:%d\n", DepartureTime);
    printf("\t\t\tTransportFee : 1000 %d\n", TransportationFee);
    printf("\t\t\tCAUTION: TAKE CARE OF YOUR OWN GOODS!\n");
    printf("\t\t\tWe value you\n" );

}
}

case 3:
{
  printf("\t\t\tBOOKING DETAILS\n");
  printf("\t\t\t================\n");
  printf("\t\t\tName:%s%s\n", &Name, &Name);
  printf("\t\t\tDestination:%s\n", &Destination);
  printf("\t\t\tSeatNumber:%d\n", &SeatNumber);
  printf("\t\t\tDepartureTime:%d\n", &DepartureTime);
  printf("\t\t\tTransportFee:%d\n", &TransportationFee);
  printf("\t\t\tCAUTION: TAKE CARE OF YOUR OWN GOODS!\n");
  printf("\t\t\tWe value you\n" );
}
case 4:
{
  printf("\t\t\tCancel Order\n");
  printf("\t\t\t================\n");
  printf("\t\t\tPlease Enter Your seat Number:\n");
  printf("\t\t\t(**Please enter the exact seat you had booked** )\n");
  scanf("%d", &SeatNumber);
  printf("\t\t\t(**Processing...** )");
  int x;
 for(x=1;x<=50;x++)
 {
 	printf("..");
 }
   printf("\t\t\tWe value you\n" );
}
case 5:
{
     printf("Are you sure you want to exit?\n");
     printf("1) Yes\n");
     printf("2) No\n");
     printf("Answer :");
     scanf("%d", &Answer);
switch (Answer)
{
  case 1:
    printf("We value You");
    exit (0);
  break ;
  case 2 :
    printf("Restart the system to get the main menu\n");
    printf("Thank You");
}
}
}
return 0;
}








